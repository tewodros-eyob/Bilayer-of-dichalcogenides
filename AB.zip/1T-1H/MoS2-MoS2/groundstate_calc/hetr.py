from ase.io import read
import numpy as np
from ase.build import bulk
from ase.optimize import BFGS
from ase.optimize import BFGSLineSearch
from gpaw import GPAW, PW, FermiDirac
import matplotlib.pyplot as plt
from ase.dft.dos import DOS
from ase.constraints import UnitCellFilter
from ase.build import mx2
from ase.constraints import StrainFilter
from ase.visualize import view
from ase.optimize import LBFGS
from ase.spacegroup import crystal
from ase.constraints import ExpCellFilter

calc=GPAW(mode=PW(600), occupations=FermiDirac(0.1), xc='PBE', kpts=(8, 8, 1))

system=read('/home/tewodros/Desktop/Hetrostructure/HTR/revised/HTR/MoS2-MoS2/MoS2-1T.traj')
#system = mx2(formula='MoS2', kind='1T', a=3.18, size=1, vacuum=2)
system.center()
system.center(axis=2, vacuum=7.0)


atoms = read('/home/tewodros/Desktop/Hetrostructure/HTR/revised/HTR/MoS2-MoS2/MoS2-2H.traj')
#atoms= mx2(formula='MoS2', kind='2H', a=3.18, size=1, vacuum=2)
atoms.center()
atoms.center(axis=2, vacuum=1.0)
#h=6.0
#location = 0.5*(system.positions[0]+system.positions[1])
#atoms.translate(-atoms.get_center_of_mass() + location + (0, 0, h))

system=system+atoms
system.pbc=True
system.center()
system.center(axis=2, vacuum=2.0)
view(system)

system.calc = calc
ucf = UnitCellFilter(system)

opt = LBFGS(ucf, logfile='MoSMoS.log', trajectory='MoSMoS.traj')
opt.run(fmax=0.005)
