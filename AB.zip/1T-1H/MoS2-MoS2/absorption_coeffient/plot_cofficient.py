import numpy as np
from ase.parallel import paropen
#from numpy import log as ln
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter

#plt.figure(figsize=(7, 5))

d = np.loadtxt('df.csv', delimiter=',')


#I_0=2*np.pi*(1/(10**(-4)))
u=4*(np.pi)*1e-7 # (H⋅m^{-1})
p=8.854*1e-12
#c=299792458
#l=np.linspace(0, 3, 10000)
o=np.sqrt(p*u)*d[:,0]*(1)*np.sqrt(np.sqrt(d[:,3]*d[:,3]+d[:,4]*d[:,4])-d[:,3])
#o=np.sqrt(2)*(d[:,0]/c)*np.sqrt(np.sqrt(d[:,3]*d[:,3]+d[:,4]*d[:,4])-d[:,3])
fd=open('data.csv', 'w') # Here we consider optical gap at spontanous rise at 10^-9
for v, e in zip(d[:,0],o):
    print(' {0}  {1} '.format(v, e), file=fd)

n=np.sqrt(1/2)*np.sqrt(np.sqrt(d[:,3]*d[:,3]+d[:,4]*d[:,4])+d[:,3])
fd=open('index.csv', 'w')
for v, e in zip(d[:,0],n):
    print(' {0}  {1} '.format(v, e), file=fd)


plt.plot(d[:,0], o, '--r', label=r'$\mathrm{MoS_{2}-MoS_{2}}$')
plt.legend()
plt.xlabel('Energy [eV]', fontsize=10)
plt.ylabel(r'$\mathrm{\alpha(\omega)[arb.unit]}$', fontsize=10)
#plt.xlabel('$\lambda$[nm]', fontsize=10)
#plt.ylabel('$I(\omega) [cm^{-1}]$', fontsize=10)
plt.grid('on', c='b')
plt.xlim(1.0, 3)
#plt.ylim(0, 0.03)
plt.savefig('absorption_co.eps', bbox_inches='tight')
plt.show()


