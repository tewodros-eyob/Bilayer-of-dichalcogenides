from BoltzTraP2.units import Ha, eV
from ase.units import Ry
import numpy as np
from ase.parallel import paropen
import matplotlib.pyplot as plt
import matplotlib
from glob import glob
from gpaw import GPAW

# Multiply sigmas by the relaxation time:
# THINGS THAT NEED TO BE CHANGED.

font ={'size'   : 16}
matplotlib.rc('font', **font)

# Tensor component ordering in interpolate.* files:
# xx xy xz? yx yy yz zx zy zz
# https://groups.google.com/g/boltztrap/c/p6c2mOraEyM/m/Ax7JZ_4EAgAJ

gpw = glob('*.gpw')

# Print out the cell being used incase multiple .gpw files in one directory.
print("Using this file to determine uc volume: ", gpw[0])
calc = GPAW(gpw[0])

# Calculate cell volume and convert to cm^3
Vol_ang = calc.atoms.cell.volume

# If you're not using GPAW , you need to
# input your own volume manually.
Vol = Vol_ang * 1.0e-24

#doping_types = ["holes", "electrons"]
doping_types = ["electrons", "holes"]
colors = {"holes":"green",
          "electrons":"red"}

colors1 = {"holes":"black",
          "electrons":"blue"}
mark = {"holes":"*", "electrons":"s"}

mark1 = {"holes":"d", "electrons":"."}
assign = {"holes":"$\mathrm{h^{+}}$", "electrons":"$\mathrm{e^{-}}$"}

plt.subplots(1, 2, figsize = (14, 6))
for i in doping_types:
    condtens = np.genfromtxt(f'interpolation.dope_{i}.condtens', skip_header=1)
    Ef = condtens[:, 0] * Ry  # Ef: Ry -> eV
    T = condtens[:, 1]  # Leave T in Kelvin
    N = condtens[:, 2] / Vol  # N : e/uc -> e/cm^3

    sxx = condtens[:, 3]
    syy = condtens[:, 7]
    szz = condtens[:, 11]

    Sxx = condtens[:, 12]
    Syy = condtens[:, 16]
    Szz = condtens[:, 20]
    kapa= condtens[:, 7]
   # linestyle=linestyle
    plt.subplot(1, 2, 1)
    #plt.plot(x, [i*2]*10, marker=marker, linestyle='')
    plt.plot(T, np.abs(1e-14*1000*(Sxx+Syy+Szz)**2*(sxx+syy+szz)/3), color = colors[i], marker=mark[i])
    plt.title(r'$\mathrm{1T/1H-MoSe_{2}-WS_{2}}$', x=0.30, y=0.20, fontsize=16)    
    #plt.title("Seebeck Coefficient v.s. Temperature")
    plt.ylabel(r"$S^2\sigma$ [mWm$^{-1}$K$^{-2}$]")
    plt.xlabel("Temperature [K]")
    xy=plt.plot(T, np.abs(1e-14*1000*(Sxx+Syy+Szz)**2*(sxx+syy+szz)/3), color = colors[i])
    data=xy[0].get_data()
    print(data)

    plt.subplot(1, 2, 2)
    plt.plot(T, np.abs(1000000*(Sxx+Syy+Szz)/3), color = colors[i], marker=mark[i], label = assign[i])
  #  plt.title("Seebeck Coefficient v.s. Temperature")
    plt.ylabel("|$S$| [$\mu$ V K$^{-1}$]")
    plt.xlabel("Temperature [K]")
    plt.legend(loc='upper left')
    yx=plt.plot(T, np.abs(1000000*(Sxx+Syy+Szz)/3), color = colors[i])
    data1=yx[0].get_data()
    print(data1)

    yxis=plt.subplot(1, 2, 2).twinx()
    yxis.plot(T, (np.abs(1e-14*1*(Sxx+Syy+Szz)**2*(sxx+syy+szz)/3))/(np.abs(1*(Sxx+Syy+Szz)/3))**2, color = 'b', marker='o', linestyle='-.')
    #yxis.legend(loc='lower right')
    yxis.set_ylabel('$\mathrm{\sigma[\Omega^{-1} m^{-1}]}$', fontsize='large')
    yxis.tick_params(axis='y', labelcolor='b')
    yxism=plt.plot(T, (np.abs(1e-14*1*(Sxx+Syy+Szz)**2*(sxx+syy+szz)/3))/(np.abs(1*(Sxx+Syy+Szz)/3))**2, color = colors[i])
    data2=yxism[0].get_data()
    print(data2)

#    fd=open('seebeck.csv', 'w')
#for color[i], e in zip(T, np.abs(1e-14*1000*(Sxx+Syy+Szz)**2*(sxx+syy+szz)/3)):
 #   print(' {0}  {1} '.format(color[i], e), file=fd)
 
#plt.legend(loc='upper right')
plt.tight_layout()
plt.savefig('MSeWS_1T_1H.eps', dpi=600)
plt.show()


