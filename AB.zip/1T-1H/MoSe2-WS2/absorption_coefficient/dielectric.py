from gpaw.mpi import world
from ase.build import mx2
from gpaw import GPAW, PW, FermiDirac
from gpaw.response.df import DielectricFunction
from ase.parallel import paropen
from ase.io import read
import numpy as np
import matplotlib.pyplot as plt
from ase.calculators.dftd3 import DFTD3
from gpaw.xc.vdw import VDWFunctional
vdw = VDWFunctional('vdW-DF2', Nalpha=24)
from ase.visualize import view


df = DielectricFunction(calc='../thermoelectric/gs_new.gpw',
                            frequencies={'type': 'nonlinear',
                                         'domega0': 0.01},                    
                            eta=0.05,  # Broadening parameter.
                            ecut=50)



df1_w, df2_w = df.get_dielectric_function(direction='x')
omega_w = df.get_frequencies()
'''
df.get_eels_spectrum()

if world.rank == 0:
    plt.figure(figsize=(7, 5))
    plt.plot(omega_w, df2_w.real, label=r'$\mathrm{\epsilon_{1}(\omega)}$')
    plt.plot(omega_w, df2_w.imag, label=r'$\mathrm{\epsilon_{2}(\omega)}$')
    plt.xlabel('Frequency (eV)')
    plt.ylabel('$\\varepsilon$')
    plt.xlim(0, 10)
    plt.ylim(-5, None)
    plt.legend()
    plt.tight_layout()
    plt.savefig('df.eps', dpi=600)
    plt.show()
'''
