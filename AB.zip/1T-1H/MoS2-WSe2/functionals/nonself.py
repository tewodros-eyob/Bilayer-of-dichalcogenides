# web-page: si-gaps.csv
from ase.build import bulk
from ase.parallel import paropen
from ase.io import read
from gpaw import *
from gpaw.hybrids.eigenvalues import non_self_consistent_eigenvalues
from gpaw import GPAW, PW


si,calc=restart('PBE0-42.gpw', txt='new.txt')
#si = read('MoSWSe.traj') 

fd = paropen('HSE06-gaps.csv', 'w')

for k in range(42, 43, 2):
    name = f'HSE06-{k}'
    si.calc =calc#GPAW(mode=PW(600),
                 # xc='PBE',
                 # nbands=70,
                 # convergence={'bands': -20},
                 # setups={'Mo, W': '6'},      
                 # parallel={'band': 1, 'domain': 1},
                 # occupations=FermiDirac(width=0.01),
                 # kpts={'size': (k, k, 1), 'gamma': True})
    si.get_potential_energy()
   # si.calc.write(name + '.gpw', mode='all')

    # Range of eigenvalues:
    n1 = 25
    n2 = 27

    ibzkpts = si.calc.get_ibz_k_points()
    kpt_indices = []
    for kpt in [(1/3, 1/3, 0), (1/3, 1/3, 0)]:  # K and K
        # Find k-point index:
        i = abs(ibzkpts - kpt).sum(1).argmin()
        kpt_indices.append(i)

    # Do PBE0 calculation:
    epbe, vpbe, vpbe0 = non_self_consistent_eigenvalues(
        si.calc,
        'HSE06',# HSE06, B3LYP
        n1, n2,
        kpt_indices,
        snapshot=name + '.json')

    epbe0 = epbe - vpbe + vpbe0
    
    gg = epbe[0, 0, 1] - epbe[0, 0, 0]
    gx = epbe[0, 1, 1] - epbe[0, 1, 0]
    gg0 = epbe0[0, 0, 1] - epbe0[0, 0, 0]
    gx0 = epbe0[0, 1, 1] - epbe0[0, 1, 0]

    print(f'{k}, {gg:.3f}, {gx:.3f}, {gg0:.3f}, {gx0:.3f}', file=fd)
    fd.flush()

#assert abs(gg - 2.559) < 0.01
#assert abs(gx - 0.707) < 0.01
#assert abs(gg0 - 3.873) < 0.01
#assert abs(gx0 - 1.828) < 0.01
