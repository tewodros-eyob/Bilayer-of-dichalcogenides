import numpy as np
from ase import Atom, Atoms
import matplotlib.pyplot as plt
from ase.utils.eos import EquationOfState
from ase.visualize import view
from gpaw import GPAW,PW
from gpaw import *
from ase.optimize.bfgs import BFGS
from ase.build import molecule
from ase.parallel import paropen
from ase.io import *
from ase.units import Bohr
from ase.units import Ry

atoms,calc2 = restart('gs_new.gpw')

ef = calc2.get_fermi_level()


#........dos...............
energy, dos = calc2.get_dos(spin=0, width=0.4)

#.....plot............
fig, ax = plt.subplots(nrows=1, ncols=1,figsize=(5, 4))
ax.plot(energy - ef, dos,linewidth=2.0,label='2H-WS2-WSe2')
#ax.set_xlim(-3,3)
ax.set_ylim(0.0,5.0)
ax.set_xlabel('E-E$_F$ [eV]')
ax.set_ylabel('DOS [arb.unit]')
'''
leg = ax.legend(loc='upper center',shadow=True, fontsize='large')
leg.get_frame().set_facecolor('cornsilk')
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
majorLocatorx = MultipleLocator(1)
majorFormatterx = FormatStrFormatter('%d')
ax.xaxis.set_major_locator(majorLocatorx)
ax.xaxis.set_major_formatter(majorFormatterx)
'''
plt.legend()
plt.axvline(x=0.0, ymin=0.0, ymax = 4.0, linestyle=':',linewidth=1.5, color='b')
fig.savefig('DOS-WS2-WSe2.eps', bbox_inches='tight')
plt.show()

