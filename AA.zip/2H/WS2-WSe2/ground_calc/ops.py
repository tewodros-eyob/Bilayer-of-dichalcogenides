from ase.io import read
import numpy as np
from ase.build import bulk
from ase.optimize import BFGS
from ase.optimize import BFGSLineSearch
from gpaw import GPAW, PW, FermiDirac
import matplotlib.pyplot as plt
from ase.dft.dos import DOS
from ase.constraints import UnitCellFilter
from ase.build import mx2
from ase.constraints import StrainFilter
from ase.visualize import view
from ase.optimize import LBFGS
from ase.spacegroup import crystal


system = read('WSWS.traj')
#system=read('/home/tewodros/Desktop/Hetrostructure/HTR/revised/HTR/2H_2H/MoS2-MoS2/MoSMoS.traj')
#system.center()
#system*=(1,1,3)
#del system[[atom.index for atom in system if atom.index==8]]
#del system[[atom.index for atom in system if atom.index==1]]
#del system[[atom.index for atom in system if atom.index==0]]
#system[0].symbol='W'
#system[3].symbol='W'
system[4].symbol='Se'
system[5].symbol='Se'

#system.center(axis=2, vacuum=1.0)
view(system)

system.calc = GPAW(mode=PW(600), occupations=FermiDirac(0.1), xc='PBE', kpts=(8, 8, 1))
ucf = UnitCellFilter(system)#, mask=[1, 1, 0, 0, 0, 1])

opt = LBFGS(ucf, logfile='WSWSe.log', trajectory='WSWSe.traj')
opt.run(fmax=0.005)

