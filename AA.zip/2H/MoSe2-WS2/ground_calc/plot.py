import numpy as np
from numpy import log as ln
import matplotlib.pyplot as plt

d = np.loadtxt('df.csv', delimiter=',')
n=np.sqrt(1/2)*np.sqrt(np.sqrt(d[:,3]*d[:,3]+d[:,4]*d[:,4])+d[:,3])
plt.figure(figsize=(7, 5))
plt.rcParams["text.usetex"] =True
plt.plot(d[:, 0], d[:, 3], label=r'$\mathrm{\epsilon_{1}(\omega)}$', linestyle='solid')
plt.plot(d[:, 0], d[:, 4], label=r'$\mathrm{\epsilon_{2}(\omega)}$', linestyle='dashed')
plt.plot(d[:, 0], n, c='m', label=r'$\mathrm{n(\omega)}$', linestyle='-.')

plt.axhline(y=-2, color="black", linestyle='--')
plt.axhline(y=0, color="black", linestyle='--')
plt.axhline(y=-1, color="purple", linestyle='--')
plt.axhline(y=1, color="blue", linestyle='--')
plt.axhline(y=-2, color="green", linestyle='--')
plt.axhline(y=0, color="black", linestyle='--')
plt.axhline(y=-4, color="orange", linestyle='--')

plt.text(1, -0.8, r'$\mathrm{\epsilon_{1}=-1}$', size=14, color='purple')
plt.text(1, -1.8, r'$\mathrm{\epsilon_{1}=-2}$', size=14, color='green')
plt.text(1, 1.2, r'$\mathrm{\epsilon_{1}=1}$', size=14, color='blue')
plt.text(1, 0.2, r'$\mathrm{\epsilon_{1}=0}$', size=14, color='black')
plt.text(1, -4.0, r'$\mathrm{\epsilon_{1}=-4}$', size=14, color='orange')
plt.xticks(size=14)
plt.yticks(size=15)
plt.xlabel(r'$\mathrm{\hbar \omega~[eV]}$', fontsize='16')
plt.ylabel(r'$\mathrm{\varepsilon(\omega)}$', fontsize='18')
plt.title(r'$\mathrm{WS_{2}}$', x=0.15, y=0.89)
plt.xlim(0, 6)
#plt.ylim(-6, 17)
plt.legend(fontsize='16')
plt.tight_layout()
plt.savefig('WS2_df.eps', dpi=600)
plt.show()
