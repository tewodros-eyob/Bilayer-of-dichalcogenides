import numpy as np
from ase import Atom, Atoms
import matplotlib.pyplot as plt
from ase.utils.eos import EquationOfState
from ase.visualize import view
from gpaw import GPAW,PW
from gpaw import *
from ase.optimize.bfgs import BFGS
from ase.build import molecule
from ase.parallel import paropen
from ase.io import *
from ase.units import Bohr
from ase.units import Ry

atoms,calc2 = restart('gs_new.gpw')

ef = calc2.get_fermi_level()

#........pdos...............
energiesf, ldosf = calc2.get_orbital_ldos(a=0, spin=0, angular='f', width=0.4)
energiesd, ldosd = calc2.get_orbital_ldos(a=0, spin=0, angular='d', width=0.4)
energiesp, ldosp = calc2.get_orbital_ldos(a=0, spin=0, angular='p', width=0.4)
energiess, ldoss = calc2.get_orbital_ldos(a=0, spin=0, angular='s', width=0.4)

fig, ax = plt.subplots(nrows=1, ncols=1,figsize=(12, 12))
ax.plot(energiesf - ef, ldosf,linewidth=2.0,color='purple',label='f orbital')
ax.plot(energiesd - ef, ldosd,linewidth=2.0,color='cyan',label='d orbital')
ax.plot(energiesp - ef, ldosp,linewidth=2.0,color='green',label='p orbital')
ax.plot(energiess - ef, ldoss,linewidth=2.0,color='orange',label='s orbital')
ax.set_xlim(-2,2)
ax.set_ylim(0,2.0)
ax.set_xlabel('E-E$_F$ [eV]')
ax.set_ylabel('PDOS [arb.unit]')
leg = ax.legend(loc='upper right',shadow=True, fontsize='large')
'''
leg.get_frame().set_facecolor('cornsilk')
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
majorLocatorx = MultipleLocator(1)
majorFormatterx = FormatStrFormatter('%d')
ax.xaxis.set_major_locator(majorLocatorx)
ax.xaxis.set_major_formatter(majorFormatterx)
'''
plt.title('2H-MoS2-WSe2')
plt.axvline(x=0.0, ymin=0.0, ymax = 4.0, linestyle=':',linewidth=1.5, color='b')
fig.savefig('PDOS-2H-MSWSe.eps', bbox_inches='tight')
plt.show()


